from django.db import models

'''
# Create your models here.
class Admin(models.Model):
    username=models.CharField()
    password=models.CharField()
    edit_pass=models.CharField()



'''
class Student(models.Model):
    name=models.CharField(max_length=30)
    address=models.CharField(max_length=40,default='zensar')
    sid=models.IntegerField(primary_key=True)
    grade=models.CharField(max_length=30,default='kemba')
    phonenumber=models.IntegerField(default=180112233)


class Attendence(models.Model):
    name=models.CharField(max_length=30)
    sid=models.IntegerField()
    grade=models.CharField(max_length=30)
    percentage=models.CharField(max_length=30,default='33%')
     
    date=models.CharField(max_length=30)
    checkin=models.CharField(max_length=30)
    checkout=models.CharField(max_length=30)
    
    
    
   
   


