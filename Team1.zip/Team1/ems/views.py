from django.shortcuts import render,redirect
from .models import *
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.db.models import Q
from django.contrib import messages




# Create your views here.

def user(request):
    return render(request,'index2.html',context={})
   
def signup(request):
    if request.method == 'POST':
        # un = request.POST.get("username")
        us=request.POST.get('name')
        em = request.POST.get("email")
        pas = request.POST.get("password")
        userObj=User.objects.create_user(us,em,pas)
        userObj.save()
    else:
        return render(request, "signupform.html", context={})
    return redirect("ggc")

def index(request):
    return render(request,'index.html')

def add(request):
    if request.method == 'POST':
        a=request.POST.get('student_name')
        b=request.POST.get('student_address')
        c=request.POST.get('student_id')
        d=request.POST.get('student_standard')
        
        e=request.POST.get('ph')
        f= Student(name=a,address=b,sid=c,grade=d,phonenumber=e)
        f.save()
        

    else:
        return render(request,'page4.html',context={})
    return HttpResponse('Data is inserted sucessfully')
       
    
def view(request):
    emps=Student.objects.all()
    return render(request,'ll.html',context={'emps':emps})

def Aadd(request):
    if request.method == 'POST':
        a=request.POST.get('name')
        b=request.POST.get('id')
        c=request.POST.get('grade')
   
        e=request.POST.get('date')
        f=request.POST.get('in')
        g=request.POST.get('out')
        i=request.POST.get('per')
        h= Attendence(name=a,sid=b,grade=c,date=e,checkin=f,checkout=g,percentage=i)
        h.save()
    else:
        return render(request,'dadd.html',context={})
    return HttpResponse('Data is inserted sucessfully')

def dlist(request):
    emps=Student.objects.all()
    return render(request,'ld.html',context={'emps':emps})

def dfilt(request):
    filt= Attendence.objects.filter(sid=9)
  
    if filt:
        return render(request,'df.html',context={'filt':filt})
      

def dfilt1(request):
    filt1= Attendence.objects.filter(sid=8)
  
    if filt1:
        return render(request,'df2.html',context={'filt1':filt1})


    
  






